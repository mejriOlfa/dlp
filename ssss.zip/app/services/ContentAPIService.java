package services;

public class ContentAPIService {
    // This is an empty service, we'll implement some code soon !
}
